test_results_format=[["John",{
    "Q1":{
        "time":1,
        "catagory":"placeholder",
        "answered":"correct"
    },
    "Q2":{
        "time":1,
        "catagory":"placeholder",
        "answered":"correct"
    }
}],["John"]]

#resets token
#response_codes[api_request('https://opentdb.com/api_token.php?command=reset&token='+token,"response_code")]
#Checks internet connection https://stackoverflow.com/questions/3764291/how-can-i-see-if-theres-an-available-and-active-network-connection-in-python
