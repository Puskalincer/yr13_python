array = "IAHFIUHEIWHIFHEIW"

while True:
    print(array)
    array=array+array